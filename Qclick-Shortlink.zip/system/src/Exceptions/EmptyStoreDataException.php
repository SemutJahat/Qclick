<?php


namespace SleekDB\Exceptions;

class EmptyStoreDataException extends \Exception {}
