<?php


namespace SleekDB\Exceptions;


class IdNotAllowedException extends \Exception {}