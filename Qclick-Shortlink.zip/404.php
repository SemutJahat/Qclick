<?php 

$template = file_get_contents(__DIR__ . '/system/template/404.html');
die($template);
