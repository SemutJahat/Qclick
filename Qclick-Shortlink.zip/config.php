<?php 

$config['maindomain'] = 'luho.dev'; // isi domain utama

?>